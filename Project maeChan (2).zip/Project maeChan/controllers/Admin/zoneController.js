const controller ={};
const { validationResult } = require('express-validator');

controller.show=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query('SELECT zone.id,zone.zname,zone.remark,market.name as market FROM zone join market on zone.market=market.id',(err,zone)=>{
            res.render('../views/Admin/Zone/zoneView',{
                data:zone,session:req.session
            });
        });
    });
};


controller.add = (req, res) => {
    data = null;
    req.getConnection((err, conn) => {
        conn.query('SELECT id, name FROM market', (err,market) => {
            res.render('../views/Admin/Zone/zoneAdd',{
                data1:market,session:req.session
    });
});
});
};

controller.addpost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/zone/add');
    } else {
        req.session.success = true;
        req.session.topic = "เพิ่มข้อมูลสำเร็จ!";
        const data = req.body;
        const market = data.name;
        req.getConnection((err, conn) => {
            conn.query('INSERT INTO zone SET ?', [data,market], (err, result) => {
                if (err) {
                    res.json(err);
                }
                res.redirect('/zone/list');
            });
        });
    }
};

controller.edit = (req, res) => {
    const idToEdit = req.params.id;
    req.getConnection((err, conn) => {
        conn.query('SELECT * FROM zone WHERE id = ?', [idToEdit], (err, data) => {
            conn.query('SELECT * FROM market', (err, market) => {   
            if (err) {
                return res.status(500).json(err);
            }
            res.render('../views/Admin/Zone/zoneEdit', { 
                data1:market,data2:data,session:req.session });
        });
    });
    });
};

controller.editPost = (req, res) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        req.session.errors=errors;
        req.session.success =false;
        return  res.redirect('/editzone/'+ req.params.id)
    }else{
        req.session.success=true;
        req.session.topic="แก้ไขข้อมูลสำเร็จ!";
        const {id} = req.params;
            const data = req.body;
            const market = data.name;
                req.getConnection((err, conn) => {
                    conn.query('UPDATE zone SET zname=?, market=?, remark=? WHERE id = ?', [data.zname,data.market,data.remark, id], (err) => {
                        if (err) {
                return res.status(500).json(err);
            }
            res.redirect('/zone/list'); 
        });
    });
}};

controller.delete=(req, res) => {
    const data = req.body.data;
    res.render('../views/Admin/Zone/confirmDelzone',{
        data:data,session:req.session
    });
};

controller.del=(req,res) => {
    req.session.success=true;
    req.session.topic="ลบข้อมูลสำเร็จ!";
    const idToDelete = req.params.id;
    req.getConnection((err,conn) =>{
        conn.query('DELETE FROM zone WHERE id = ?', [idToDelete], (err,) => {
            res.redirect('/zone/list');
            }
        );
    });
};

module.exports=controller;