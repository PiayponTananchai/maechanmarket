const controller = {};
const { validationResult } = require('express-validator');

controller.show = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT dt.id, dt.dname, am.aname, pv.pname FROM maechan_market.district as dt join amphures as am on dt.amphure_id=am.id join province as pv on dt.province_id=pv.id ', (err, district) => {
            res.render('../views/Admin/District/districtView', {
                data: district, session: req.session
            });
        });
    });
};

controller.add = (req, res) => {
    const data = null;
    req.getConnection((err, conn) => {
        conn.query('SELECT id,pname FROM province', (err, province) => {
            conn.query('SELECT id,aname FROM amphures', (err, amphures) => {
                res.render('../views/Admin/District/districtA', {
                    province,
                    amphures,
                    session: req.session
                });
            });
        });
    });
};

controller.addpost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/district/add');
    } else {
        req.session.success = true;
        req.session.topic = "เพิ่มข้อมูลสำเร็จ!";
        const data = req.body;
        const amphure_id = data.aname;
        const province_id = data.pname;
        req.getConnection((err, conn) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            conn.query('INSERT INTO district SET ?', [data, amphure_id, province_id], (err) => {
                if (err) {
                    res.status(500).json(err);
                    return;
                }
                res.redirect('/district/list');
            });
        });
    }
};

controller.edit = (req, res) => {
    const idToEdit = req.params.id;
    req.getConnection((err, conn) => {
        conn.query('SELECT * FROM province', (err, province) => {
            conn.query('SELECT * FROM amphures', (err, amphures) => {
                conn.query('SELECT * FROM district WHERE id = ?', [idToEdit], (err, data) => {
                    res.render('../views/District/districtE', {
                        data1: data,
                        province,
                        amphures,
                        session: req.session
                    });
                });
            });
        });
    });
};

controller.editPost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/editdistrict/' + req.params.id)
    } else {
        req.session.success = true;
        req.session.topic = "แก้ไขข้อมูลสำเร็จ!";
        const { id } = req.params;
        const data = req.body;
        const dname = data.dname;
        const amphure_id = data.amphure_id;
        const province_id = data.province_id;
        req.getConnection((err, conn) => {
            conn.query('UPDATE district SET dname = ?,amphure_id = ?,province_id = ? WHERE id = ?', [dname, amphure_id,province_id, id], (err) => {
                if (err) {
                    return res.status(500).json(err);
                }
                res.redirect('/district/list');
            });
        });
    }
};

controller.delete = (req, res) => {
    const data = req.body.data;
    res.render('../views/Admin/District/confirmDelDistrict', {
        data: data, session: req.session
    });
};

controller.del = (req, res) => {
    req.session.success = true;
    req.session.topic = "ลบข้อมูลสำเร็จ!";
    const idToDelete = req.params.id;
    req.getConnection((err, conn) => {
        conn.query('DELETE FROM district WHERE id = ?', [idToDelete], (err, ads04) => {
            res.redirect('/district/list');
        }
        );
    });
};

module.exports = controller;