const controller ={};
const { validationResult } = require('express-validator');

controller.show=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query('SELECT * FROM userlogin',(err,user)=>{
            res.render('../views/Admin/Userlogin/userV',{
                data:user,session:req.session
            });
        });
    });
};

controller.add = (req, res) => {
            res.render('../views/Admin/Userlogin/userA',{
                session:req.session
    });
};

controller.addpost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/user/add');
    } else {
        req.session.success = true;
        req.session.topic = "เพิ่มข้อมูลสำเร็จ!";
        const data = req.body;
        req.getConnection((err, conn) => {
            conn.query('INSERT INTO userlogin SET ?', [data], (err, result) => {
                if (err) {
                    res.json(err);
                }
                res.redirect('/user/list');
            });
        });
    }
};

controller.edit = (req, res) => {
    const idToEdit = req.params.id;
    req.getConnection((err, conn) => {
        conn.query('SELECT * FROM userlogin WHERE id = ?', [idToEdit], (err, data) => {
            res.render('../views/Admin/Userlogin/userE', { 
                data1:data,session:req.session });
        });
    });
};

controller.editPost = (req, res) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        req.session.errors=errors;
        req.session.success =false;
        return  res.redirect('/edituser/'+ req.params.id)
    }else{
        req.session.success=true;
        req.session.topic="แก้ไขข้อมูลสำเร็จ!";
        const {id} = req.params;
            const data = {
                username: req.body.username,
                password:req.body.password,
                name:req.body.name
            }
                req.getConnection((err, conn) => {
                    conn.query('UPDATE userlogin SET ? WHERE id = ?', [data, id], (err) => {
                        if (err) {
                return res.status(500).json(err);
            }
            res.redirect('/user/list'); 
        });
    });
}};

controller.delete=(req, res) => {
    const data = req.body.data;
    res.render('../views/Admin/Userlogin/confirmDelUserlog',{
        data:data,session:req.session
    });
};

controller.del=(req,res) => {
    req.session.success=true;
    req.session.topic="ลบข้อมูลสำเร็จ!";
    const idToDelete = req.params.id;
    req.getConnection((err,conn) =>{
        conn.query('DELETE FROM userlogin WHERE id = ?', [idToDelete], (err) => {
            res.redirect('/user/list');
            }
        );
    });
};

module.exports=controller;