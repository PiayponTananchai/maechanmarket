const controller ={};
const { validationResult } = require('express-validator');

controller.rejister = (req, res) => {
    if (typeof req.session.userid !== 'undefined') { res.redirect('/login');}else{
    res.render('../views/Login/rejister',{
        session: req.session
    });
}};

controller.rejisterPost = (req, res) => {
    const errors = validationResult(req);
    const { username, password, confirmpassword, name, address } = req.body;

    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        res.render('../views/Admin/Login/rejister', { session: req.session });
    } else {
        // Check if password and confirmpassword match
        if (password !== confirmpassword) {
            req.session.errors = [{ msg: "Password and Confirm Password do not match." }];
            req.session.success = false;
            return res.render('../views/Admin/Login/rejister', { session: req.session });
        }

        req.getConnection((err, conn) => {
            // Use the correct query for checking existing user
            conn.query('SELECT * FROM userlogin WHERE username = ? AND  password = ? AND name = ? AND  confirmpassword = ? address = ?', [username,password,name,confirmpassword,address], (err, data) => {
                // Handle the result of the query
                if (data.length > 0) {
                    req.session.errors = [{ msg: "Username already exists." }];
                    req.session.success = false;
                    res.render('../views/Admin/Login/rejister', { session: req.session });
                } else {
                    // Continue with your logic for successful registration
                    // You might want to hash the password before storing it in the database
                }
            });
        });
    }
};



controller.add = (req, res) => {
    const errors = validationResult(req);
    const { password, confirmpassword } = req.body;

    // Check if password and confirmpassword match
    if (confirmpassword !== password) {
        req.session.errors =  "Password and Confirm Password do not match.";
        req.session.success = false;
        return res.render('../views/Login/rejister', { session: req.session });
    } else if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/rejister/add');
    } else {
        req.session.success = true;
        // req.session.topic = "สมัครสมาชิกสำเร็จ!";
        const data = req.body;
        
        req.getConnection((err, conn) => {
            conn.query('INSERT INTO userlogin SET ?', [data], (err) => {
                if (err) {
                    res.json(err);
                }
                res.redirect('/login0');
            });
        });
    }
};

module.exports=controller;