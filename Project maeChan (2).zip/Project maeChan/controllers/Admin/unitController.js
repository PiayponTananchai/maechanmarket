const controller = {};
const { validationResult } = require('express-validator');

controller.show = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT unit.id, unit.uname, zone.zname FROM unit join zone on unit.zone=zone.id', (err, unit) => {
            res.render('../views/Admin/Unit/unitView', {
                data: unit, session: req.session
            });
        });
    });
};

controller.add = (req, res) => {
    const data = null;
    req.getConnection((err, conn) => {
        conn.query('SELECT id,zname FROM zone', (err, zone) => {
                res.render('../views/Admin/Unit/unitA', {
                    zone,
                    session: req.session
                });
            });
        });
};

controller.addpost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/unit/add');
    } else {
        req.session.success = true;
        req.session.topic = "เพิ่มข้อมูลสำเร็จ!";
        const data = req.body;
        const zone = data.zname;
        req.getConnection((err, conn) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            conn.query('INSERT INTO unit SET ?', [data, zone], (err) => {
                if (err) {
                    res.status(500).json(err);
                    return;
                }
                res.redirect('/unit/list');
            });
        });
    }
};

controller.edit = (req, res) => {
    const idToEdit = req.params.id;
    req.getConnection((err, conn) => {
            conn.query('SELECT * FROM zone', (err, zone) => {
                conn.query('SELECT * FROM unit WHERE id = ?', [idToEdit], (err, data) => {
                    res.render('../views/Admin/Unit/unitE', {
                        data1: data,
                        zone,
                        session: req.session
                    });
                });
            });
        });
};

controller.editPost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/editunit/' + req.params.id)
    } else {
        req.session.success = true;
        req.session.topic = "แก้ไขข้อมูลสำเร็จ!";
        const { id } = req.params;
        const data = req.body;
        const uname = data.uname;
        const zone = data.zone;
        req.getConnection((err, conn) => {
            conn.query('UPDATE unit SET uname = ?,zone = ? WHERE id = ?', [uname, zone, id], (err) => {
                if (err) {
                    return res.status(500).json(err);
                }
                res.redirect('/unit/list');
            });
        });
    }
};

controller.delete = (req, res) => {
    const data = req.body.data;
    res.render('../views/Admin/Unit/confirmDelunit', {
        data: data, session: req.session
    });
};

controller.del = (req, res) => {
    req.session.success = true;
    req.session.topic = "ลบข้อมูลสำเร็จ!";  
    const idToDelete = req.params.id;
    req.getConnection((err, conn) => {
        conn.query('DELETE FROM unit WHERE id = ?', [idToDelete], (err, ) => {
            res.redirect('/unit/list');
        }
        );
    });
};

controller.unitA = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT unit.id, unit.uname, zone.zname FROM unit join zone on unit.zone=zone.id where zone.id = 1', (err, unit) => {
            res.render('../views/Unit/unitchoose/unitA', {
                data: unit, session: req.session
            });
        });
    });
};

controller.unitB = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT unit.id, unit.uname, zone.zname FROM unit join zone on unit.zone=zone.id where zone.id = 2', (err, unit) => {
            res.render('../views/Unit/unitchoose/unitB', {
                data: unit, session: req.session
            });
        });
    });
};

controller.unitC = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT unit.id, unit.uname, zone.zname FROM unit join zone on unit.zone=zone.id where zone.id = 3', (err, unit) => {
            res.render('../views/Unit/unitchoose/unitC', {
                data: unit, session: req.session
            });
        });
    });
};

controller.unitD = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT unit.id, unit.uname, zone.zname FROM unit join zone on unit.zone=zone.id where zone.id = 4', (err, unit) => {
            res.render('../views/Unit/unitchoose/unitD', {
                data: unit, session: req.session
            });
        });
    });
};

controller.unitE = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT unit.id, unit.uname, zone.zname FROM unit join zone on unit.zone=zone.id where zone.id = 5', (err, unit) => {
            res.render('../views/Unit/unitchoose/unitE', {
                data: unit, session: req.session
            });
        });
    });
};

controller.unitF = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT unit.id, unit.uname, zone.zname FROM unit join zone on unit.zone=zone.id where zone.id = 7', (err, unit) => {
            res.render('../views/Unit/unitchoose/unitF', {
                data: unit, session: req.session
            });
        });
    });
};

controller.unitG = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT unit.id, unit.uname, zone.zname FROM unit join zone on unit.zone=zone.id where zone.id = 8', (err, unit) => {
            res.render('../views/Unit/unitchoose/unitG', {
                data: unit, session: req.session
            });
        });
    });
};

module.exports = controller;