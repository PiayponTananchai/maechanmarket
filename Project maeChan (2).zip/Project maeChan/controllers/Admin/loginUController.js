const controller ={};
const { validationResult } = require('express-validator');

controller.login = (req, res) => {
    if (typeof req.session.userid !== 'undefined') { res.redirect('/market/list');}else{
    res.render('../views/Admin/Login/loginUview',{
        session: req.session
    });
}};

controller.loginPost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        res.render('../views/Admin/Login/loginUview', { session: req.session });
    } else {
        const username = req.body.username;
        const password = req.body.password;
        req.getConnection((err, conn) => {
            if (err) {
                res.json(err);
            } else {
                conn.query('SELECT * FROM userlogin WHERE username = ? AND password = ?', [username, password], (err, data) => {
                    if (err) {
                        res.json(err);
                    } else {
                        if (data.length > 0) {
                            req.session.userid = data[0].id;
                            req.session.mode = data[0].enable;
                            if (data[0].enable === 0) { // Admin
                                res.redirect('/market/list');
                            } else if (data[0].enable === 1) { // Regular user
                                res.redirect('/UZA');
                            } else {
                                // Handle other cases if needed
                                res.redirect('/login0');
                            }
                        } else {
                            res.redirect('/login0');
                        }
                    }
                });
            }
        });
    }
};

controller.logout = (req, res) => {
    req.session.destroy(function(error){
        res.redirect('/');
    })
};

controller.paper = (req, res) => {
    if (typeof req.session.userid !== 'undefined') { res.redirect('/login');}else{
    res.render('../views/Admin/Login/paper',{
        session: req.session
    });
}};

module.exports=controller;