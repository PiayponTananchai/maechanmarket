const express = require('express');
const router = express.Router();
const annualmemberController = require('../../controllers/Admin/annualmemberController');


router.get('/annualmember/list', annualmemberController.show39);


router.get('/annualmember/add', annualmemberController.add);
router.post('/annualmember/add', annualmemberController.add39);

router.get('/editannualmember/:id', annualmemberController.edit);
router.post('/editannualmember/:id',annualmemberController.editPost);

router.get('/reserveAnnualmember/:id', annualmemberController.reserve);
router.post('/reserveAnnualmember/:id',annualmemberController.reservePost);


router.get('/annualmemberDelete/:id',annualmemberController.delete);
router.post('/annualmemberDelete/:id',annualmemberController.delete39);

router.get('/anm/unit',annualmemberController.unit);

router.get('/UZA', annualmemberController.UZA);

router.get('/anmA', annualmemberController.anmA);
router.get('/anmB', annualmemberController.anmB);
router.get('/anmC', annualmemberController.anmC);
router.get('/anmD', annualmemberController.anmD);
router.get('/anmE', annualmemberController.anmE);
router.get('/anmF', annualmemberController.anmF);
router.get('/anmG', annualmemberController.anmG);

router.get('/anmA0', annualmemberController.anmA0);
router.get('/anmB0', annualmemberController.anmB0);
router.get('/anmC0', annualmemberController.anmC0);
router.get('/anmD0', annualmemberController.anmD0);
router.get('/anmE0', annualmemberController.anmE0);
router.get('/anmF0', annualmemberController.anmF0);
router.get('/anmG0', annualmemberController.anmG0);

router.get('/anmAll', annualmemberController.anmall);

router.get('/WalkInget', annualmemberController.walkIn);

router.get('/anmAU', annualmemberController.anmAU);
router.get('/anmBU', annualmemberController.anmBU);
router.get('/anmCU', annualmemberController.anmCU);
router.get('/anmDU', annualmemberController.anmDU);
router.get('/anmEU', annualmemberController.anmEU);
router.get('/anmFU', annualmemberController.anmFU);
router.get('/anmGU', annualmemberController.anmGU);

router.get('/anmA0U', annualmemberController.anmA0U);
router.get('/anmB0U', annualmemberController.anmB0U);
router.get('/anmC0U', annualmemberController.anmC0U);
router.get('/anmD0U', annualmemberController.anmD0U);
router.get('/anmE0U', annualmemberController.anmE0U);
router.get('/anmF0U', annualmemberController.anmF0U);
router.get('/anmG0U', annualmemberController.anmG0U);
router.get('/anmAllU', annualmemberController.anmallU);

router.get('/anmAW', annualmemberController.anmAW);
router.get('/anmBW', annualmemberController.anmBW);
router.get('/anmCW', annualmemberController.anmCW);
router.get('/anmDW', annualmemberController.anmDW);
router.get('/anmEW', annualmemberController.anmEW);
router.get('/anmFW', annualmemberController.anmFW);
router.get('/anmGW', annualmemberController.anmGW);
router.get('/anmAllW', annualmemberController.anmallW);

module.exports = router;