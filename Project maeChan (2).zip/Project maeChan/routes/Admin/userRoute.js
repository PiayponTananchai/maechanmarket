const express = require('express');
const router = express.Router();
const userController = require('../../controllers/Admin/userController');


router.get('/user/list', userController.show);

router.get('/user/add', userController.add)
router.post('/user/add',userController.addpost);

router.get('/edituser/:id',userController.edit);
router.post('/edituser/:id',userController.editPost);

router.get('/deleteuser/:id',userController.delete);
router.post('/deleteuser/:id',userController.del);

module.exports = router;