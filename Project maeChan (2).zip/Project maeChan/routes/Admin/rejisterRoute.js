const express = require('express');
const router = express.Router();
const rejisterController = require('../../controllers/Admin/rejisterController');

router.get('/rejister', rejisterController.rejister)
router.post('/rejister', rejisterController.rejisterPost)

router.post('/rejister/add', rejisterController.add)

module.exports = router;