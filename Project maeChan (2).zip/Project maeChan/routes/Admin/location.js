const express = require('express');
const router = express.Router();
const provinceController = require('../../controllers/Admin/provinceController');


router.get('/porvince',provinceController.province);

module.exports = router;