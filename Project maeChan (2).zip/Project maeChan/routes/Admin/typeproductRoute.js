const express = require('express');
const router = express.Router();
const typeproductController = require('../../controllers/Admin/typeproductController');


router.get('/typeproduct/list', typeproductController.show);

router.get('/typeproduct/add', typeproductController.add)
router.post('/typeproduct/add',typeproductController.addpost);

router.get('/edittypeproduct/:id',typeproductController.edit);
router.post('/edittypeproduct/:id',typeproductController.editPost);

router.get('/deletetypeproduct/:id',typeproductController.delete);
router.post('/deletetypeproduct/:id',typeproductController.del);

module.exports = router;