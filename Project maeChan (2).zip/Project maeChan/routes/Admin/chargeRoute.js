const express = require('express');
const router = express.Router();
const chargeController = require('../../controllers/Admin/chargeController');


router.get('/charge/list', chargeController.show);

router.get('/charge/add', chargeController.add)
router.post('/charge/add',chargeController.addpost);

router.get('/editcharge/:id',chargeController.edit);
router.post('/editcharge/:id',chargeController.editPost);

router.get('/deletecharge/:id',chargeController.delete);
router.post('/deletecharge/:id',chargeController.del);




module.exports = router;