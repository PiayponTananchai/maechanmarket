const express = require('express');
const router = express.Router();
const locktradingController = require('../../controllers/Admin/locktradingController');


router.get('/locktrading/a', locktradingController.showA);

router.post('/locktrading/Apost', locktradingController.addApost);

router.post('/locktrading/clear/:id', locktradingController.clear);
router.post('/locktrading/replace/:id', locktradingController.replace);


router.get('/marketchoose/add', locktradingController.add);

router.post('/marketchoose/add', locktradingController.addpost)

router.get('/marketdatechoose/add', locktradingController.marketdateChoose);
router.post('/marketdatechoose/add', locktradingController.marketdatechooseAddpost);

router.get('/zonechoose/list', locktradingController.choose);


module.exports = router;