const express = require('express');
const router = express.Router();
const marketController = require('../../controllers/Admin/marketController');


router.get('/market/list', marketController.show);


router.get('/market/add', marketController.add)
router.post('/market/add',marketController.addpost);

router.get('/editmarket/:id',marketController.edit);
router.post('/editmarket/:id',marketController.editPost);

router.get('/deletemarket/:id',marketController.delete);
router.post('/deletemarket/:id',marketController.del);

module.exports = router;