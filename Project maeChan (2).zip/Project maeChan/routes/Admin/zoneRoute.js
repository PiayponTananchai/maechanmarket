const express = require('express');
const router = express.Router();
const zoneController = require('../../controllers/Admin/zoneController');


router.get('/zone/list', zoneController.show);


router.get('/zone/add', zoneController.add);
router.post('/zone/add',zoneController.addpost);

router.get('/editzone/:id',zoneController.edit);
router.post('/editzone/:id',zoneController.editPost);

router.get('/deletezone/:id',zoneController.delete);
router.post('/deletezone/:id',zoneController.del);

module.exports = router;