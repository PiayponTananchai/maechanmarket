const express = require('express');
const router = express.Router();
const traderController = require('../../controllers/Admin/traderController');


router.get('/trader/list', traderController.show39);

router.get('/trader/add', traderController.add)
router.post('/trader/add',traderController.add39);

router.get('/edittrader/:id',traderController.edit39);
router.post('/edittrader/:id',traderController.editPost39);

router.get('/deletetrader/:id',traderController.delete);
router.post('/deletetrader/:id',traderController.delete39);

router.get('/report/list', traderController.report);

router.get('/III/list', traderController.amphures);
router.get('/DDD/list', traderController.district);
router.get('/AAA/list', traderController.am1);
router.get('/SSS/list', traderController.dis1);


router.get('/zonechooseA/list', traderController.chooseA);
router.get('/zonechooseB/list', traderController.chooseB);
router.get('/zonechooseC/list', traderController.chooseC);
router.get('/zonechooseD/list', traderController.chooseD);
router.get('/zonechooseE/list', traderController.chooseE);
router.get('/zonechooseF/list', traderController.chooseF);
router.get('/zonechooseG/list', traderController.chooseG);

module.exports = router;