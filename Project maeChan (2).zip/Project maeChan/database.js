const mysql = require("mysql");
const dbConnetion = mysql.createPool({
    host:'localhost',
    user:'piyapon',
    password:'1579900943795ball',
    database:'maechan_market'
}).promise()

module.exports = dbConnetion;