process.env.TZ = 'Asia/Bangkok';
const express=require('express');
const body=require('body-parser'); 
const cookie=require('cookie-parser');
const session=require('express-session');
const mysql=require('mysql');
const connection=require('express-myconnection');
const app=express();


// app.use(express.urlencoded({ extended: true }));
// app.use((req, res, next) => {
//   if (req.body.unit) {
//     req.body.unit = parseInt(req.body.unit);
//   }
//   next();
// });



const path = require('path');
const zoneRoute = require('./routes/Admin/zoneRoute');
const traderRoute = require('./routes/Admin/traderRoute');
const loginRoute = require('./routes/Admin/loginUroute');
const rejisterRoute = require('./routes/Admin/rejisterRoute');
const payRoute = require('./routes/Admin/payRoute');
const marketRoute = require('./routes/Admin/marketRoute');
const typeproductRoute = require('./routes/Admin/typeproductRoute');
const userRoute = require('./routes/Admin/userRoute');
const marketmap = require('./routes/Admin/marketmap');
const annualmember = require('./routes/Admin/annualmemberRoute');
const marketdate = require('./routes/Admin/marketdateRoute');
const province = require('./routes/Admin/provinceRoute');
const amphures = require('./routes/Admin/amphuresRoute');
const district = require('./routes/Admin/districtRoute');
const unit = require('./routes/Admin/unitRoute');
const annual = require('./routes/Admin/annualRoute');
const locktrading = require('./routes/Admin/locktradingRoute');
const charge = require('./routes/Admin/chargeRoute');
const walkincustomer = require('./routes/Admin/walkincustomerRoute');


const uuidv4 = require('uuid');

app.set('view engine','ejs');

app.get('/pay/add',function(req,res){
    res.render('upload');
});

const upload = require('express-fileupload');
app.use(upload());

app.use(express.static('public'));

app.post('/upload',function(req,res){
    if(req.files){
        var file = req.files.filename;
        if(!Array.isArray(file)){
                var filename = uuidv4.v4()+"."+file.name.split(".")[1];
                file.mv('./public/name'+filename,function(err){
                    if(err){ console.log(err) }
                })
        }else{
        for(var i=0;i<file.length; i++){ 
        var filename = uuidv4.v4()+"."+file[i].name.split(".")[1];
        file[i].mv('./public/name'+filename,function(err){
            if(err){ console.log(err) }
        })
     }
    }
    }
    res.redirect('/');
});

app.use(express.static('public'));
app.use(express.urlencoded({extended:true})); 
app.use(cookie());
app.use(session({
    secret:'12',
    resave:true,
    saveUninitialized:true
}));

app.use(connection(mysql,{
    host:'localhost',
    user:'piyapon',
    password:'1579900943795ball',
    port:3306,
    database:'maechan_market'
},'single'));   


app.use('/',traderRoute);
app.use('/',loginRoute);
app.use('/',rejisterRoute);

app.use('/',payRoute);
app.use('/',zoneRoute);
app.use('/',marketRoute);
app.use('/',typeproductRoute);
app.use('/',userRoute);
app.use('/',marketmap);
app.use('/',annualmember);
app.use('/',marketdate);
app.use('/',province);
app.use('/',amphures);
app.use('/',district);
app.use('/',unit);
app.use('/',annual);
app.use('/',locktrading);
app.use('/',charge);
app.use('/',walkincustomer);



app.listen('8040');