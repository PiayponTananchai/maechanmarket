const express = require('express');
const router = express.Router();
const marketmap=require('../../controllers/Admin/marketmapControler');


router.get('/marketmap', marketmap.marketmap);

router.get('/marketmap2', marketmap.marketmap2);

module.exports = router;