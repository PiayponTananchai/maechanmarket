const express = require('express');
const router = express.Router();
const unitController = require('../../controllers/Admin/unitController');


router.get('/unit/list', unitController.show);

router.get('/unit/add', unitController.add)
router.post('/unit/add',unitController.addpost);

router.get('/editunit/:id',unitController.edit);
router.post('/editunit/:id',unitController.editPost);

router.get('/deleteunit/:id',unitController.delete);
router.post('/deleteunit/:id',unitController.del);

router.get('/unit/zoneA', unitController.unitA);
router.get('/unit/zoneB', unitController.unitB);
router.get('/unit/zoneC', unitController.unitC);
router.get('/unit/zoneD', unitController.unitD);
router.get('/unit/zoneE', unitController.unitE);
router.get('/unit/zoneF', unitController.unitF);
router.get('/unit/zoneG', unitController.unitG);

module.exports = router;