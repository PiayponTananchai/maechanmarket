const express = require('express');
const router = express.Router();
const payController = require('../../controllers/Admin/payController');


router.get('/pay/list', payController.show39);

router.get('/pay/add', payController.add)
router.post('/pay/add',payController.add39);

router.get('/editpay/:id',payController.edit39);
router.post('/editpay/:id',payController.editPost39);

router.get('/deletepay/:id',payController.delete);
router.post('/deletepay/:id',payController.delete39);

module.exports = router;