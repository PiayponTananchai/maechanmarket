const express = require('express');
const router = express.Router();
const marketdateController = require('../../controllers/Admin/marketdateController');


router.get('/marketdate/list', marketdateController.show39);

router.get('/marketdate/add', marketdateController.add);
router.post('/marketdate/add', marketdateController.add39);

router.get('/editmarketdate/:id',marketdateController.edit);
router.post('/editmarketdate/:id',marketdateController.editPost);

router.get('/deletemarketdate/:id',marketdateController.delete);
router.post('/deletemarketdate/:id',marketdateController.del);

module.exports = router;