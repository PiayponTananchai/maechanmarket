const express = require('express');
const router = express.Router();
const provinceController = require('../../controllers/Admin/provinceController');


router.get('/province/list', provinceController.show);

router.get('/province/add', provinceController.add)
router.post('/province/add',provinceController.addpost);

router.get('/editprovince/:id',provinceController.edit);
router.post('/editprovince/:id',provinceController.editPost);

router.get('/deleteprovince/:id',provinceController.delete);
router.post('/deleteprovince/:id',provinceController.del);


module.exports = router;