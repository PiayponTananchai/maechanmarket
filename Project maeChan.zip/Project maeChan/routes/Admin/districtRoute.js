const express = require('express');
const router = express.Router();
const districtController = require('../../controllers/Admin/districtController');


router.get('/district/list', districtController.show);

router.get('/district/add', districtController.add)
router.post('/district/add',districtController.addpost);

router.get('/editdistrict/:id',districtController.edit);
router.post('/editdistrict/:id',districtController.editPost);

router.get('/deletedistrict/:id',districtController.delete);
router.post('/deletedistrict/:id',districtController.del);

module.exports = router;