const express = require('express');
const router = express.Router();
const login=require('../../controllers/Admin/loginUController');
//const validator = require('../controllers/validator');


router.get('/login0', login.login);
router.get('/login', login.login);
router.post('/login',/* validator.login,*/login.loginPost);

router.get('/logout', login.logout);
router.get('/', login.paper);

module.exports = router;