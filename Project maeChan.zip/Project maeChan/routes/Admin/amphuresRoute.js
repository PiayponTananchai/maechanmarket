const express = require('express');
const router = express.Router();
const amphuresController = require('../../controllers/Admin/amphuresController');


router.get('/amphures/list', amphuresController.show);

router.get('/amphures/add', amphuresController.add)
router.post('/amphures/add',amphuresController.addpost);

router.get('/editamphures/:id', amphuresController.edit);

router.post('/editamphures/:id',amphuresController.editPost);

router.get('/deleteamphures/:id',amphuresController.delete);
router.post('/deleteamphures/:id',amphuresController.del);

module.exports = router;