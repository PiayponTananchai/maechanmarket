const express = require('express');
const router = express.Router();
const walkincustomerController = require('../../controllers/Admin/walkincustomerController');


router.get('/walkincustomer/list', walkincustomerController.show);

router.get('/walkincustomer/add', walkincustomerController.add)
router.post('/walkincustomer/add',walkincustomerController.addpost);

router.get('/editwalkincustomer/:id',walkincustomerController.edit);
router.post('/editwalkincustomer/:id',walkincustomerController.editPost);

router.get('/deletewalkincustomer/:id',walkincustomerController.delete);
router.post('/deletewalkincustomer/:id',walkincustomerController.del);




module.exports = router;