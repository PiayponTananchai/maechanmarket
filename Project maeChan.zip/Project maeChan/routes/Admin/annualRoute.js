const express = require('express');
const router = express.Router();
const annualController = require('../../controllers/Admin/annualController');


router.get('/annual/list', annualController.show);

router.get('/annual/add', annualController.add)
router.post('/annual/add',annualController.addpost);

router.get('/editannual/:id',annualController.edit);
router.post('/editannual/:id',annualController.editPost);

router.get('/deleteannual/:id',annualController.delete);
router.post('/deleteannual/:id',annualController.del);

module.exports = router;