const controller = {};
const { validationResult } = require('express-validator');
controller.show39 = (req, res) => {
    req.getConnection((err, conn) => {
        if (err) {
            res.status(500).json(err);
            return;
        }

        const query = `
            SELECT anm.id, z.zname, u.uname, 
                   CONCAT(tp.tname, " ", td.detail) AS type1, 
                   CONCAT(tpd.tname, " ", td.detail2) AS type2, 
                   CONCAT(td.firstname, " ", td.lastname) AS tdname, 
                   anm.enableuse, anm.enablesell, anm.remark 
            FROM maechan_market.annualmember AS anm 
            JOIN unit AS u ON anm.unit = u.id 
            LEFT JOIN trader AS td ON anm.trader = td.id 
            LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
            LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
            JOIN zone AS z ON anm.zone = z.id 
            ORDER BY anm.id;
        `;

        conn.query(query, (err, annualmember) => {
            if (err) {
                res.status(500).json(err);
                return;
            }

            // Calculate the number of unique zones
            // const uniqueZones = new Set(annualmember.map(item => item.zname));
            // const numberOfZones = uniqueZones.size;

            // Calculate available and sellable slots
            const availableAndSellableSlots = annualmember.filter(item => item.enableuse === 1 && item.enablesell === 0).length;

            const sellNOT = annualmember.filter(item => item.enableuse === 1 && item.enablesell === 1).length;

            // Calculate the number of unique traders
            const uniqueTraders = new Set(annualmember.map(item => item.tdname));
            const numberTraders = uniqueTraders.size;

        

            const totalSlots = annualmember.length;
const result = (totalSlots - availableAndSellableSlots - sellNOT) * 30;

            

            // Pass the calculated values to the template
            res.render('../views/Admin/Annualmember/annualmemberView', {
                data: annualmember,
                session: req.session,
                availableAndSellableSlots: availableAndSellableSlots,
                numbertrader: numberTraders,
                sellNOT: sellNOT,
                result: result
            });
        });
    });
};



controller.add = (req, res) => {
    const data = null;
    req.getConnection((err, conn) => {
        conn.query('SELECT id,uname FROM unit', (err, unit) => {
            conn.query('SELECT id,CONCAT(trader.firstname," ",trader.lastname) as tdname FROM trader', (err, trader) => {
                conn.query('SELECT id,zname FROM zone', (err, zone) => {
                    res.render('../views/Admin/Annualmember/annualmemberAdd', {
                        data,
                        unit,
                        trader,
                        zone,
                        session: req.session
                    });
                });
            });
        });
    });
};


controller.add39 = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/annualmember/add');
    } else {
        req.session.success = true;
        req.session.topic = "เพิ่มข้อมูลสำเร็จ!";
        const data = req.body;
        const units = Array.isArray(data.unit) ? data.unit : [data.unit]; // ตรวจสอบว่าข้อมูลหน่วยเป็น array หรือไม่

        req.getConnection((err, conn) => {
            if (err) {
                res.status(500).json(err);
                return;
            }

            // ใช้การวน loop เพื่อเพิ่มข้อมูลหน่วยที่ผู้ใช้เลือกแต่ละรายการ
            units.forEach((unit) => {
                conn.query('INSERT INTO annualmember (zone, unit, trader, enableuse, enablesell, remark) VALUES (?, ?, ?, ?, ?, ?)', [data.zone, unit, data.trader || null, data.enableuse,data.enablesell,data.remark], (err) => {
                    if (err) {
                        console.error("Error inserting data:", err);
                        return;
                    }
                });
            });

            res.redirect('/annualmember/list');
        });
    }
};


controller.delete = (req, res) => {
    const data = req.body.data;
    res.render('../views/Admin/Annualmember/confirmannualmember', {
        data: data, session: req.session
    });
};

controller.delete39 = (req, res) => {
    req.session.success = true;
    req.session.topic = "ลบข้อมูลสำเร็จ!";
    const idToDelete = req.params.id;
    req.getConnection((err, conn) => {
        conn.query('DELETE FROM annualmember WHERE id = ?', [idToDelete], (err) => {
            res.redirect('/annualmember/list');
        });
    });
};


controller.edit = (req, res) => {
    const idToEdit = req.params.id;
    req.getConnection((err, conn) => {
        conn.query('SELECT id,zname FROM zone', (err, zone) => {
            conn.query('SELECT id,uname FROM unit', (err, unit) => {
                conn.query('SELECT id,CONCAT(trader.firstname," ",trader.lastname) as tdname FROM trader', (err, trader) => {
                    conn.query('SELECT * FROM annualmember WHERE id = ?', [idToEdit], (err, data) => {
                        res.render('../views/Admin/Annualmember/annualmemberE', {
                            data1: data,
                            zone,
                            unit,
                            trader,
                            session: req.session
                        });
                    });
                });
            });
        });
    });
};

controller.editPost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/editannualmember/' + req.params.id)
    } else {
        req.session.success = true;
        req.session.topic = "แก้ไขข้อมูลสำเร็จ!";
        const { id } = req.params;
        const data = req.body;
        const zone = data.zone;
        const unit = data.unit;
        const trader = data.trader;
        const enableuse = data.enableuse;
        const enablesell = data.enablesell;
        const remark = data.remark;

        req.getConnection((err, conn) => {
            conn.query('UPDATE annualmember SET zone = ?, unit = ?, trader = ?, enableuse = ?, enablesell = ?, remark = ? WHERE id = ?', [zone, unit, trader, enableuse, enablesell,remark, id], (err) => {
                if (err) {
                    return res.status(500).json(err);
                }
                res.redirect('/annualmember/list');
            });
        });
    }
};

controller.unit = (req, res) => {
    req.getConnection((err, conn) => {
        const data = req.query.id;
        conn.query('SELECT * FROM unit where zone = ?;', [data], (err, zone) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            res.json({
                data: zone, session: req.session
            });
        });
    });
}


controller.reserve = (req, res) => {
    const idToEdit = req.params.id;
    req.getConnection((err, conn) => {
        conn.query('SELECT id,zname FROM zone', (err, zone) => {
            conn.query('SELECT id,uname FROM unit', (err, unit) => {
                conn.query('SELECT id,CONCAT(trader.firstname," ",trader.lastname) as tdname FROM trader', (err, trader) => {
                    conn.query('SELECT * FROM annualmember WHERE id = ?', [idToEdit], (err, data) => {
                        res.render('annualmemberE', {
                            data1: data,
                            zone,
                            unit,
                            trader,
                            session: req.session
                        });
                    });
                });
            });
        });
    });
};

controller.reservePost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/reserveAnnualmember/' + req.params.id)
    } else {
        req.session.success = true;
        req.session.topic = "แก้ไขข้อมูลสำเร็จ!";
        const { id } = req.params;
        const data = req.body;
        const zone = data.zone;
        const unit = data.unit;
        const trader = data.trader;
        const enableuse = data.enableuse;

        req.getConnection((err, conn) => {
            conn.query('UPDATE annualmember SET zone = ?, unit = ?, trader = ?, enableuse = ? WHERE id = ?', [zone, unit, trader, enableuse, id], (err) => {
                if (err) {
                    return res.status(500).json(err);
                }
                res.redirect('/annualmemberUAZ/list');
            });
        });
    }
};

controller.UZA = (req, res) => {
    req.getConnection((err, conn) => {
        if (err) {
            res.status(500).json(err);
            return;
        }

        const query = `
            SELECT anm.id, z.zname, u.uname, 
                   CONCAT(tp.tname, " ", td.detail) AS type1, 
                   CONCAT(tpd.tname, " ", td.detail2) AS type2, 
                   CONCAT(td.firstname, " ", td.lastname) AS tdname, 
                   anm.enableuse, anm.enablesell, anm.remark 
            FROM maechan_market.annualmember AS anm 
            JOIN unit AS u ON anm.unit = u.id 
            LEFT JOIN trader AS td ON anm.trader = td.id 
            LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
            LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
            JOIN zone AS z ON anm.zone = z.id 
            ORDER BY anm.id;
        `;

        conn.query(query, (err, annualmember) => {
            if (err) {
                res.status(500).json(err);
                return;
            }

            // คำนวณจำนวนโซนที่ไม่ซ้ำกัน
            const uniqueZones = new Set(annualmember.map(item => item.zname));
            const numberOfZones = uniqueZones.size;

            // คำนวณจำนวนล็อคว่างและขายได้
            const availableAndSellableSlots = annualmember.filter(item => item.enableuse === 1 && item.enablesell === 0).length;

            // คำนวณจำนวนล็อคว่างและขายไม่ได้
            const sellNOT = annualmember.filter(item => item.enableuse === 1 && item.enablesell === 1).length;

            // คำนวณจำนวนผู้ค้าที่ไม่ซ้ำกัน
            const uniqueTraders = new Set(annualmember.map(item => item.tdname));
            const numberTraders = uniqueTraders.size;

            // ส่งค่าที่คำนวณแล้วไปยังแม่แบบ (template)
            res.render('annualmemberUZA', {
                data: annualmember,
                session: req.session,
                numberOfZones: numberOfZones,
                available: availableAndSellableSlots,
                sellNOTNO: sellNOT,
                numbertraderU: numberTraders,
            });
        });
    });
};

controller.walkIn = (req, res) => {
    req.getConnection((err, conn) => {
        if (err) {
            res.status(500).json(err);
            return;
        }

        const query = `
            SELECT anm.id, z.zname, u.uname, 
                   CONCAT(tp.tname, " ", td.detail) AS type1, 
                   CONCAT(tpd.tname, " ", td.detail2) AS type2, 
                   CONCAT(td.firstname, " ", td.lastname) AS tdname, 
                   anm.enableuse, anm.enablesell, anm.remark 
            FROM maechan_market.annualmember AS anm 
            JOIN unit AS u ON anm.unit = u.id 
            LEFT JOIN trader AS td ON anm.trader = td.id 
            LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
            LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
            JOIN zone AS z ON anm.zone = z.id 
            ORDER BY anm.id;
        `;

        conn.query(query, (err, annualmember) => {
            if (err) {
                res.status(500).json(err);
                return;
            }

            // คำนวณจำนวนโซนที่ไม่ซ้ำกัน
            const uniqueZones = new Set(annualmember.map(item => item.zname));
            const numberOfZones = uniqueZones.size;

            // คำนวณจำนวนล็อคว่างและขายได้
            const availableAndSellableSlots = annualmember.filter(item => item.enableuse === 1 && item.enablesell === 0).length;

            // คำนวณจำนวนล็อคว่างและขายไม่ได้
            const sellNOT = annualmember.filter(item => item.enableuse === 1 && item.enablesell === 1).length;

            // คำนวณจำนวนผู้ค้าที่ไม่ซ้ำกัน
            const uniqueTraders = new Set(annualmember.map(item => item.tdname));
            const numberTraders = uniqueTraders.size;

            // ส่งค่าที่คำนวณแล้วไปยังแม่แบบ (template)
            res.render('../views/Annualmember/WalkIn/walkInget', {
                data: annualmember,
                session: req.session,
                numberOfZones: numberOfZones,
                available: availableAndSellableSlots,
                sellNOTNO: sellNOT,
                numbertraderU: numberTraders,
            });
        });
    });
};



controller.anmA=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 1
        ORDER BY anm.id;
    `,(err,anmA)=>{
            res.render('../views/Admin/Annualmember/Admin/anmA',{
                data:anmA,session:req.session
            });
        });
    });
};

controller.anmB=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 2
        ORDER BY anm.id;
    `,(err,anmB)=>{
            res.render('../views/Admin/Annualmember/Admin/anmB',{
                data:anmB,session:req.session
            });
        });
    });
};

controller.anmC=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 3
        ORDER BY anm.id;
    `,(err,anmC)=>{
            res.render('../views/Admin/Annualmember/Admin/anmC',{
                data:anmC,session:req.session
            });
        });
    });
};

controller.anmD=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 4
        ORDER BY anm.id;
    `,(err,anmD)=>{
            res.render('../views/Admin/Annualmember/Admin/anmD',{
                data:anmD,session:req.session
            });
        });
    });
};

controller.anmE=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 5
        ORDER BY anm.id;
    `,(err,anmE)=>{
            res.render('../views/Admin/Annualmember/Admin/anmE',{
                data:anmE,session:req.session
            });
        });
    });
};

controller.anmF=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 7
        ORDER BY anm.id;
    `,(err,anmF)=>{
            res.render('../views/Admin/Annualmember/Admin/anmF',{
                data:anmF,session:req.session
            });
        });
    });
};

controller.anmG=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 8
        ORDER BY anm.id;
    `,(err,anmG)=>{
            res.render('../views/Admin/Annualmember/Admin/anmG',{
                data:anmG,session:req.session
            });
        });
    });
};

controller.anmA0=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 1 AND anm.enableuse = 1 AND anm.enablesell = 0
        ORDER BY anm.id;
    `,(err,anmA)=>{
            res.render('../views/Admin/Annualmember/Admin/anmA0',{
                data:anmA,session:req.session
            });
        });
    });
};

controller.anmB0=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 2 AND anm.enableuse = 1 AND anm.enablesell = 0
        ORDER BY anm.id;
    `,(err,anmB)=>{
            res.render('../views/Admin/Annualmember/Admin/anmB0',{
                data:anmB,session:req.session
            });
        });
    });
};

controller.anmC0=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 3 AND anm.enableuse = 1 AND anm.enablesell = 0
        ORDER BY anm.id;
    `,(err,anmC)=>{
            res.render('../views/Admin/Annualmember/Admin/anmC0',{
                data:anmC,session:req.session
            });
        });
    });
};

controller.anmD0=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 4 AND anm.enableuse = 1 AND anm.enablesell = 0
        ORDER BY anm.id;
    `,(err,anmD)=>{
            res.render('../views/Admin/Annualmember/Admin/anmD0',{
                data:anmD,session:req.session
            });
        });
    });
};

controller.anmE0=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 5 AND anm.enableuse = 1 AND anm.enablesell = 0
        ORDER BY anm.id;
    `,(err,anmE)=>{
            res.render('../views/Admin/Annualmember/Admin/anmE0',{
                data:anmE,session:req.session
            });
        });
    });
};

controller.anmF0=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 7 AND anm.enableuse = 1 AND anm.enablesell = 0
        ORDER BY anm.id;
    `,(err,anmF)=>{
            res.render('../views/Admin/Annualmember/Admin/anmF0',{
                data:anmF,session:req.session
            });
        });
    });
};

controller.anmG0=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 8 AND anm.enableuse = 1 AND anm.enablesell = 0
        ORDER BY anm.id;
    `,(err,anmG)=>{
            res.render('../views/Admin/Annualmember/Admin/anmG0',{
                data:anmG,session:req.session
            });
        });
    });
};

controller.anmall=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE anm.enableuse = 1 AND anm.enablesell = 0
        ORDER BY anm.id;
    `,(err,anmall)=>{
            res.render('../views/Admin/Annualmember/Admin/anmAll',{
                data:anmall,session:req.session
            });
        });
    });
};


controller.anmAU=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 1
        ORDER BY anm.id;
    `,(err,anmA)=>{
            res.render('../views/Admin/Annualmember/User/anmAU',{
                data:anmA,session:req.session
            });
        });
    });
};

controller.anmBU=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 2
        ORDER BY anm.id;
    `,(err,anmB)=>{
            res.render('../views/Admin/Annualmember/User/anmBU',{
                data:anmB,session:req.session
            });
        });
    });
};

controller.anmCU=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 3
        ORDER BY anm.id;
    `,(err,anmC)=>{
            res.render('../views/Admin/Annualmember/User/anmCU',{
                data:anmC,session:req.session
            });
        });
    });
};

controller.anmDU=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 4
        ORDER BY anm.id;
    `,(err,anmD)=>{
            res.render('../views/Admin/Annualmember/User/anmDU',{
                data:anmD,session:req.session
            });
        });
    });
};

controller.anmEU=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 5
        ORDER BY anm.id;
    `,(err,anmE)=>{
            res.render('../views/Admin/Annualmember/User/anmEU',{
                data:anmE,session:req.session
            });
        });
    });
};

controller.anmFU=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 7
        ORDER BY anm.id;
    `,(err,anmF)=>{
            res.render('../views/Admin/Annualmember/User/anmFU',{
                data:anmF,session:req.session
            });
        });
    });
};

controller.anmGU=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 8
        ORDER BY anm.id;
    `,(err,anmG)=>{
            res.render('../views/Admin/Annualmember/User/anmGU',{
                data:anmG,session:req.session
            });
        });
    });
};

controller.anmA0U=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 1 AND anm.enableuse = 1
        ORDER BY anm.id;
    `,(err,anmA)=>{
            res.render('../views/Admin/Annualmember/User/anmA0U',{
                data:anmA,session:req.session
            });
        });
    });
};

controller.anmB0U=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 2 AND anm.enableuse = 1
        ORDER BY anm.id;
    `,(err,anmB)=>{
            res.render('../views/Admin/Annualmember/User/anmB0U',{
                data:anmB,session:req.session
            });
        });
    });
};

controller.anmC0U=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 3 AND anm.enableuse = 1
        ORDER BY anm.id;
    `,(err,anmC)=>{
            res.render('../views/Admin/Annualmember/User/anmC0U',{
                data:anmC,session:req.session
            });
        });
    });
};

controller.anmD0U=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 4 AND anm.enableuse = 1
        ORDER BY anm.id;
    `,(err,anmD)=>{
            res.render('../views/Admin/Annualmember/User/anmD0U',{
                data:anmD,session:req.session
            });
        });
    });
};

controller.anmE0U=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 5 AND anm.enableuse = 1
        ORDER BY anm.id;
    `,(err,anmE)=>{
            res.render('../views/Admin/Annualmember/User/anmE0U',{
                data:anmE,session:req.session
            });
        });
    });
};

controller.anmF0U=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 7 AND anm.enableuse = 1
        ORDER BY anm.id;
    `,(err,anmF)=>{
            res.render('../views/Admin/Annualmember/User/anmF0U',{
                data:anmF,session:req.session
            });
        });
    });
};

controller.anmG0U=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 8 AND anm.enableuse = 1
        ORDER BY anm.id;
    `,(err,anmG)=>{
            res.render('../views/Admin/Annualmember/User/anmG0U',{
                data:anmG,session:req.session
            });
        });
    });
};

controller.anmallU=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE anm.enableuse = 1 AND anm.enablesell = 0
        ORDER BY anm.id;
    `,(err,anmall)=>{
            res.render('../views/Admin/Annualmember/User/anmAllU',{
                data:anmall,session:req.session
            });
        });
    });
};

controller.anmAW=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 1
        ORDER BY anm.id;
    `,(err,anmA)=>{
            res.render('../views/Admin/Annualmember/WalkIn/anmAW',{
                data:anmA,session:req.session
            });
        });
    });
};

controller.anmBW=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 2
        ORDER BY anm.id;
    `,(err,anmB)=>{
            res.render('../views/Admin/Annualmember/WalkIn/anmBW',{
                data:anmB,session:req.session
            });
        });
    });
};

controller.anmCW=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 3
        ORDER BY anm.id;
    `,(err,anmC)=>{
            res.render('../views/Admin/Annualmember/WalkIn/anmCW',{
                data:anmC,session:req.session
            });
        });
    });
};

controller.anmDW=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 4
        ORDER BY anm.id;
    `,(err,anmD)=>{
            res.render('../views/Admin/Annualmember/WalkIn/anmDW',{
                data:anmD,session:req.session
            });
        });
    });
};

controller.anmEW=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 5
        ORDER BY anm.id;
    `,(err,anmE)=>{
            res.render('../views/Admin/Annualmember/WalkIn/anmEW',{
                data:anmE,session:req.session
            });
        });
    });
};

controller.anmFW=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 7
        ORDER BY anm.id;
    `,(err,anmF)=>{
            res.render('../views/Admin/Annualmember/WalkIn/anmFW',{
                data:anmF,session:req.session
            });
        });
    });
};

controller.anmGW=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE z.id = 8
        ORDER BY anm.id;
    `,(err,anmG)=>{
            res.render('../views/Admin/Annualmember/WalkIn/anmGW',{
                data:anmG,session:req.session
            });
        });
    });
};

controller.anmallW=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query(`
        SELECT anm.id, z.zname, u.uname, 
               CONCAT(tp.tname, " ", td.detail) AS type1, 
               CONCAT(tpd.tname, " ", td.detail2) AS type2, 
               CONCAT(td.firstname, " ", td.lastname) AS tdname, 
               anm.enableuse, anm.enablesell, anm.remark 
        FROM maechan_market.annualmember AS anm 
        JOIN unit AS u ON anm.unit = u.id 
        LEFT JOIN trader AS td ON anm.trader = td.id 
        LEFT JOIN typeproduct AS tp ON td.typeproduct = tp.id 
        LEFT JOIN typeproduct AS tpd ON td.typeproduct2 = tpd.id 
        JOIN zone AS z ON anm.zone = z.id 
        WHERE anm.enableuse = 1 AND anm.enablesell = 0
        ORDER BY anm.id;
    `,(err,anmall)=>{
            res.render('../views/Admin/Annualmember/WalkIn/anmAllW',{
                data:anmall,session:req.session
            });
        });
    });
};
module.exports = controller;