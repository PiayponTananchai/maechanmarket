const controller = {};
const { validationResult } = require('express-validator');

controller.show = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT am.id , am.aname, pv.pname FROM amphures as am join province as pv on am.province_id=pv.id ;', (err, amphures) => {
            res.render('../views/Admin/Amphures/amphuresView', {
                data: amphures, session: req.session
            });
        });
    });
};

controller.add = (req, res) => {
    const data = null;
    req.getConnection((err, conn) => {
        conn.query('SELECT id,pname FROM province', (err, province) => {
            res.render('../views/Admin/Amphures/amphuresA', {
                province,
                session: req.session
            });
        });
    });
};
controller.addpost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/amphures/add');
    } else {
        req.session.success = true;
        req.session.topic = "เพิ่มข้อมูลสำเร็จ!";
        const data = req.body;
        const amphuers_id = data.amphuers_id;
        req.getConnection((err, conn) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            conn.query('INSERT INTO amphures SET ?', [data, amphuers_id], (err) => {
                if (err) {
                    res.status(500).json(err);
                    return;
                }
                res.redirect('/amphures/list');
            });
        });
    }
};

controller.edit = (req, res) => {
    const idToEdit = req.params.id;
    req.getConnection((err, conn) => {
        conn.query('SELECT * FROM amphures WHERE id = ?', [idToEdit], (err, data) => {
            conn.query('SELECT * FROM province', (err, province) => {
                if (err) {
                    return res.status(500).json(err);
                }
                res.render('../views/Admin/Amphures/amphuresE', {
                    data1: data,
                    data2 :province,
                    session: req.session
                });
            });
        });
    });
};

controller.editPost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/editamphures/' + req.params.id) 
    } else {
        req.session.success = true;
        req.session.topic = "แก้ไขข้อมูลสำเร็จ!";
        const { id } = req.params;
        const data = req.body;
        const aname = data.aname;
        const province_id = data.pname;
        req.getConnection((err, conn) => {
            conn.query('UPDATE amphures SET aname = ?,province_id = ? WHERE id = ?', [aname, province_id, id], (err) => {
                if (err) {
                    return res.status(500).json(err);
                }
                res.redirect('/amphures/list');
            });
        });
    }
};

controller.delete = (req, res) => {
    const data = req.body.data;
    res.render('../views/Admin/Amphures/confirmDelAmphures', {
        data: data, session: req.session
    });
};

controller.del = (req, res) => {
    req.session.success = true;
    req.session.topic = "ลบข้อมูลสำเร็จ!";
    const idToDelete = req.params.id;
    req.getConnection((err, conn) => {
        conn.query('DELETE FROM amphures WHERE id = ?', [idToDelete], (err) => {
            res.redirect('/amphures/list');
        }
        );
    });
};
module.exports = controller;