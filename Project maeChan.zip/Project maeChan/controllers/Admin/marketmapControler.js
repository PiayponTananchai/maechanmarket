const controller = {};
const { validationResult } = require('express-validator');

controller.marketmap=(req, res) => {
    const data = req.body.data;
    res.render('marketmap',{
        data:data,session:req.session
    });
};

controller.marketmap2=(req, res) => {
    const data = req.body.data;
    res.render('marketmap2',{
        data:data,session:req.session
    });
};
module.exports = controller;