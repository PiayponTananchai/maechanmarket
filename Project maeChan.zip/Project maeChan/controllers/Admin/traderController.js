const controller = {};
const { validationResult } = require('express-validator');

controller.show39 = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT trader.id, z.zname, CONCAT(trader.firstname," ",trader.lastname) as FnLn, trader.idcard, CONCAT(trader.housenumber," หมู่ที่",trader.village," ต.",d.dname," อ.",a.aname," จ.",p.pname) as addressID, trader.dr, trader.ar, trader.pr, CONCAT(trader.Hnr," หมู่ที่",trader.Vn,"  ต.",dis.dname," อ.",amp.aname," จ.",pro.pname) as addressReal, trader.phone, CONCAT(t.tname," : ",trader.detail) as typepor,CONCAT(typ.tname," : ",trader.detail2) as typepor2, q.TroF, trader.remark FROM trader LEFT JOIN district AS d ON trader.district = d.id LEFT JOIN amphures AS a ON trader.amphures = a.id LEFT JOIN province AS p ON trader.province = p.id LEFT JOIN district AS dis ON trader.dr = dis.id LEFT JOIN amphures AS amp ON trader.ar = amp.id LEFT JOIN province AS pro ON trader.pr = pro.id LEFT JOIN typeproduct AS t ON trader.typeproduct = t.id LEFT JOIN zone AS z ON trader.zone = z.id LEFT JOIN qrcode AS q ON trader.Qrcode = q.id LEFT join typeproduct as typ on trader.typeproduct2=typ.id WHERE trader.firstname IS NOT NULL ORDER BY trader.id;', (err, trader) => {
            if (err) {
                res.status(500).json(err);
                return;
            }

             // Calculate the number of unique zones
             const uniqueTraders = new Set(trader.map(item => item.id));
            const numberTraders = uniqueTraders.size;

            res.render('../views/Admin/Trader/traderView', {
                data: trader, session: req.session,
                numbertrader: numberTraders,
            });
        });
    });
};

controller.add = (req, res) => {
    const data = null;
    req.getConnection((err, conn) => {
        conn.query('SELECT id,zname FROM zone', (err, zone) => {
            conn.query('SELECT id,dname,amphure_id FROM district', (err, district) => {
                conn.query('SELECT id,aname,province_id FROM amphures', (err, amphures) => {
                    conn.query('SELECT id,pname FROM province', (err, province) => {
                        conn.query('SELECT id,tname FROM typeproduct', (err, typeproduct) => {
                            conn.query('SELECT id,TroF FROM qrcode', (err, qrcode) => {
                                res.render('../views/Admin/Trader/traderAdd', {
                                    typeproduct,
                                    zone,
                                    data,
                                    district,
                                    amphures,
                                    province,
                                    qrcode,
                                    session: req.session
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

controller.add39 = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/trader/add')
    } else {
        req.session.success = true;
        req.session.topic = "เพิ่มข้อมูลสำเร็จ!";
        const data = req.body;
        req.getConnection((err, conn) => {
            conn.query('INSERT INTO trader (zone, firstname, lastname, idcard, housenumber, village, district, amphures, province, Hnr, Vn, dr, ar, pr, phone, typeproduct, detail, typeproduct2, detail2, Qrcode) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', 
            [data.zone, data.firstname, data.lastname, data.idcard, data.housenumber, data.village, data.dname || null, data.aname || null, data.pname || null, data.Hnr, data.Vn, data.dr || null, data.ar || null, data.pr || null, data.phone, data.tname || null, data.detail, data.typeproduct2 || null, data.detail2, data.TroF || null], (err) => {
                if (err) {
                    res.status(500).json(err);
                    return;
                }
                res.redirect('/trader/list');
            });
        });
    };
};



controller.edit39 = (req, res) => {
    const { id } = req.params;
    req.getConnection((err, conn) => {
        conn.query('SELECT * FROM trader WHERE id = ?', [id], (err, data) => {
            conn.query('SELECT * FROM typeproduct', (err, typeproduct) => {
                conn.query('SELECT * FROM zone', (err, zone) => {
                    conn.query('SELECT * FROM unit', (err, unit) => {
                        conn.query('SELECT * FROM district', (err, district) => {
                            conn.query('SELECT * FROM amphures', (err, amphures) => {
                                conn.query('SELECT * FROM province', (err, province) => {
                                    conn.query('SELECT * FROM qrcode', (err, qrcode) => {
                                        res.render('../views/Admin/Trader/traderEdit', {
                                            id,
                                            data1: typeproduct,
                                            data2: zone,
                                            data3: unit,
                                            data5: data,
                                            data6: district,
                                            data7: amphures,
                                            data8: province,
                                            data12: qrcode,
                                            session: req.session
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};

controller.editPost39 = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/edittrader/' + req.params.id)
    } else {
        req.session.success = true;
        req.session.topic = "แก้ไขข้อมูลสำเร็จ!";
        const { id } = req.params;
        const data = req.body;
        const zone = data.zname;;
        const firstname = data.firstname;
        const lastname = data.lastname;
        const idcard = data.idcard;
        const housenumber = data.housenumber;
        const village = data.village;
        const district = data.dname;
        const amphures = data.aname;
        const province = data.pname;
        const Hnr = data.Hnr;
        const Vn = data.Vn;
        const dr = data.dr;
        const ar = data.ar;
        const pr = data.pr;
        const phone = data.phone;
        const typeproduct = data.tname;
        const detail = data.detail;
        const typeproduct2 = data.typeproduct2;
        const detail2 = data.detail2;
        const Qrcode = data.Qrcode;
        req.getConnection((err, conn) => {
            conn.query(
                'UPDATE trader SET zone=?, firstname=?, lastname=?, idcard=?, housenumber=?, village=?, district=?, amphures=?, province=?, Hnr=?, Vn=?, dr=?, ar=?, pr=?, phone=?, typeproduct=?, detail=?, typeproduct2=?, detail2=?, Qrcode=? WHERE id = ?',
                [zone, firstname, lastname, idcard, housenumber, village, district, amphures, province, Hnr, Vn, dr || null, ar, pr, phone, typeproduct, detail, typeproduct2 || null, detail2, Qrcode, id],
                (err) => {
                    if (err) {
                        return res.status(500).json(err);
                    }
                    res.redirect('/trader/list');
                });
        });
    }
};


controller.delete = (req, res) => {
    const data = req.body.data;
    res.render('../views/Admin/Trader/confirmDelTrader', {
        data: data, session: req.session
    });
};

controller.delete39 = (req, res) => {
    req.session.success = true;
    req.session.topic = "ลบข้อมูลสำเร็จ!";
    const idToDelete = req.params.id;
    req.getConnection((err, conn) => {
        conn.query('DELETE FROM trader WHERE id = ?', [idToDelete], (err) => {
            res.redirect('/trader/list');
        });
    });
};




controller.report = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT trader.id, z.zname, CONCAT(trader.firstname," ",trader.lastname) as FnLn, trader.idcard, CONCAT(trader.housenumber," หมู่ที่",trader.village," ต.",d.dname," อ.",a.aname," จ.",p.pname) as addressID, trader.dr, trader.ar, trader.pr, CONCAT(trader.Hnr," หมู่ที่",trader.Vn,"  ต.",dis.dname," อ.",amp.aname," จ.",pro.pname) as addressReal, trader.phone, CONCAT(t.tname," : ",trader.detail) as typepor,CONCAT(typ.tname," : ",trader.detail2) as typepor2, q.TroF, trader.remark FROM trader JOIN district AS d ON trader.district = d.id LEFT JOIN amphures AS a ON trader.amphures = a.id LEFT JOIN province AS p ON trader.province = p.id LEFT JOIN district AS dis ON trader.dr = dis.id LEFT JOIN amphures AS amp ON trader.ar = amp.id LEFT JOIN province AS pro ON trader.pr = pro.id LEFT JOIN typeproduct AS t ON trader.typeproduct = t.id LEFT JOIN zone AS z ON trader.zone = z.id LEFT JOIN qrcode AS q ON trader.Qrcode = q.id LEFT join typeproduct as typ on trader.typeproduct2=typ.id WHERE trader.firstname IS NOT NULL ORDER BY trader.id;', (err, trader) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            res.render('../views/Admin/Trader/report', {
                data: trader, session: req.session
            });
        });
    });
}

controller.am1 = (req, res) => {
    req.getConnection((err, conn) => {
        const data = req.query.id;

        conn.query('SELECT * FROM amphures where province_id = ?;',[data], (err, amphures) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            res.json( {
                data: amphures, session: req.session
            });
        });
    });
}

controller.dis1 = (req, res) => {
    req.getConnection((err, conn) => {
        const data = req.query.id;

        conn.query('SELECT * FROM district where amphure_id = ?;',[data], (err, district) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            res.json( {
                data: district, session: req.session
            });
        });
    });
}


controller.amphures = (req, res) => {
    req.getConnection((err, conn) => {
        const data = req.query.id;

        conn.query('SELECT * FROM amphures where province_id = ?;',[data], (err, amphures) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            res.json( {
                data: amphures, session: req.session
            });
        });
    });
}

controller.district = (req, res) => {
    req.getConnection((err, conn) => {
        const data = req.query.id;

        conn.query('SELECT * FROM district where amphure_id = ?;',[data], (err, district) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            res.json( {
                data: district, session: req.session
            });
        });
    });
}


controller.chooseA=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query('SELECT trader.id, z.zname, CONCAT(trader.firstname," ",trader.lastname) as FnLn, trader.idcard, CONCAT(trader.housenumber," หมู่ที่",trader.village," ต.",d.dname," อ.",a.aname," จ.",p.pname) as addressID, trader.dr, trader.ar, trader.pr, CONCAT(trader.Hnr," หมู่ที่",trader.Vn,"  ต.",dis.dname," อ.",amp.aname," จ.",pro.pname) as addressReal, trader.phone, CONCAT(t.tname," : ",trader.detail) as typepor,CONCAT(typ.tname," : ",trader.detail2) as typepor2, q.TroF, trader.remark FROM trader LEFT JOIN district AS d ON trader.district = d.id LEFT JOIN amphures AS a ON trader.amphures = a.id LEFT JOIN province AS p ON trader.province = p.id LEFT JOIN district AS dis ON trader.dr = dis.id LEFT JOIN amphures AS amp ON trader.ar = amp.id LEFT JOIN province AS pro ON trader.pr = pro.id LEFT JOIN typeproduct AS t ON trader.typeproduct = t.id LEFT JOIN zone AS z ON trader.zone = z.id LEFT JOIN qrcode AS q ON trader.Qrcode = q.id LEFT join typeproduct as typ on trader.typeproduct2=typ.id WHERE trader.firstname IS NOT NULL AND z.id=1 ORDER BY trader.id;',(err,zone)=>{
            res.render('../views/Admin/Trader/zonechoose/zoneA',{
                data:zone,session:req.session
            });
        });
    });
};

controller.chooseB=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query('SELECT trader.id, z.zname, CONCAT(trader.firstname," ",trader.lastname) as FnLn, trader.idcard, CONCAT(trader.housenumber," หมู่ที่",trader.village," ต.",d.dname," อ.",a.aname," จ.",p.pname) as addressID, trader.dr, trader.ar, trader.pr, CONCAT(trader.Hnr," หมู่ที่",trader.Vn,"  ต.",dis.dname," อ.",amp.aname," จ.",pro.pname) as addressReal, trader.phone, CONCAT(t.tname," : ",trader.detail) as typepor,CONCAT(typ.tname," : ",trader.detail2) as typepor2, q.TroF, trader.remark FROM trader LEFT JOIN district AS d ON trader.district = d.id LEFT JOIN amphures AS a ON trader.amphures = a.id LEFT JOIN province AS p ON trader.province = p.id LEFT JOIN district AS dis ON trader.dr = dis.id LEFT JOIN amphures AS amp ON trader.ar = amp.id LEFT JOIN province AS pro ON trader.pr = pro.id LEFT JOIN typeproduct AS t ON trader.typeproduct = t.id LEFT JOIN zone AS z ON trader.zone = z.id LEFT JOIN qrcode AS q ON trader.Qrcode = q.id LEFT join typeproduct as typ on trader.typeproduct2=typ.id WHERE trader.firstname IS NOT NULL AND z.id=2 ORDER BY trader.id;',(err,zone)=>{
            res.render('../views/Admin/Trader/zonechoose/zoneB',{
                data:zone,session:req.session
            });
        });
    });
};

controller.chooseC=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query('SELECT trader.id, z.zname, CONCAT(trader.firstname," ",trader.lastname) as FnLn, trader.idcard, CONCAT(trader.housenumber," หมู่ที่",trader.village," ต.",d.dname," อ.",a.aname," จ.",p.pname) as addressID, trader.dr, trader.ar, trader.pr, CONCAT(trader.Hnr," หมู่ที่",trader.Vn,"  ต.",dis.dname," อ.",amp.aname," จ.",pro.pname) as addressReal, trader.phone, CONCAT(t.tname," : ",trader.detail) as typepor,CONCAT(typ.tname," : ",trader.detail2) as typepor2, q.TroF, trader.remark FROM trader LEFT JOIN district AS d ON trader.district = d.id LEFT JOIN amphures AS a ON trader.amphures = a.id LEFT JOIN province AS p ON trader.province = p.id LEFT JOIN district AS dis ON trader.dr = dis.id LEFT JOIN amphures AS amp ON trader.ar = amp.id LEFT JOIN province AS pro ON trader.pr = pro.id LEFT JOIN typeproduct AS t ON trader.typeproduct = t.id LEFT JOIN zone AS z ON trader.zone = z.id LEFT JOIN qrcode AS q ON trader.Qrcode = q.id LEFT join typeproduct as typ on trader.typeproduct2=typ.id WHERE trader.firstname IS NOT NULL AND z.id=3 ORDER BY trader.id;',(err,zone)=>{
            res.render('../views/Admin/Trader/zonechoose/zoneC',{
                data:zone,session:req.session
            });
        });
    });

};controller.chooseD=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query('SELECT trader.id, z.zname, CONCAT(trader.firstname," ",trader.lastname) as FnLn, trader.idcard, CONCAT(trader.housenumber," หมู่ที่",trader.village," ต.",d.dname," อ.",a.aname," จ.",p.pname) as addressID, trader.dr, trader.ar, trader.pr, CONCAT(trader.Hnr," หมู่ที่",trader.Vn,"  ต.",dis.dname," อ.",amp.aname," จ.",pro.pname) as addressReal, trader.phone, CONCAT(t.tname," : ",trader.detail) as typepor,CONCAT(typ.tname," : ",trader.detail2) as typepor2, q.TroF, trader.remark FROM trader LEFT JOIN district AS d ON trader.district = d.id LEFT JOIN amphures AS a ON trader.amphures = a.id LEFT JOIN province AS p ON trader.province = p.id LEFT JOIN district AS dis ON trader.dr = dis.id LEFT JOIN amphures AS amp ON trader.ar = amp.id LEFT JOIN province AS pro ON trader.pr = pro.id LEFT JOIN typeproduct AS t ON trader.typeproduct = t.id LEFT JOIN zone AS z ON trader.zone = z.id LEFT JOIN qrcode AS q ON trader.Qrcode = q.id LEFT join typeproduct as typ on trader.typeproduct2=typ.id WHERE trader.firstname IS NOT NULL AND z.id=4 ORDER BY trader.id;',(err,zone)=>{
            res.render('../views/Admin/Trader/zonechoose/zoneD',{
                data:zone,session:req.session
            });
        });
    });
};

controller.chooseE=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query('SELECT trader.id, z.zname, CONCAT(trader.firstname," ",trader.lastname) as FnLn, trader.idcard, CONCAT(trader.housenumber," หมู่ที่",trader.village," ต.",d.dname," อ.",a.aname," จ.",p.pname) as addressID, trader.dr, trader.ar, trader.pr, CONCAT(trader.Hnr," หมู่ที่",trader.Vn,"  ต.",dis.dname," อ.",amp.aname," จ.",pro.pname) as addressReal, trader.phone, CONCAT(t.tname," : ",trader.detail) as typepor,CONCAT(typ.tname," : ",trader.detail2) as typepor2, q.TroF, trader.remark FROM trader LEFT JOIN district AS d ON trader.district = d.id LEFT JOIN amphures AS a ON trader.amphures = a.id LEFT JOIN province AS p ON trader.province = p.id LEFT JOIN district AS dis ON trader.dr = dis.id LEFT JOIN amphures AS amp ON trader.ar = amp.id LEFT JOIN province AS pro ON trader.pr = pro.id LEFT JOIN typeproduct AS t ON trader.typeproduct = t.id LEFT JOIN zone AS z ON trader.zone = z.id LEFT JOIN qrcode AS q ON trader.Qrcode = q.id LEFT join typeproduct as typ on trader.typeproduct2=typ.id WHERE trader.firstname IS NOT NULL AND z.id=5 ORDER BY trader.id;',(err,zone)=>{
            res.render('../views/Admin/Trader/zonechoose/zoneE',{
                data:zone,session:req.session
            });
        });
    });
};

controller.chooseF=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query('SELECT trader.id, z.zname, CONCAT(trader.firstname," ",trader.lastname) as FnLn, trader.idcard, CONCAT(trader.housenumber," หมู่ที่",trader.village," ต.",d.dname," อ.",a.aname," จ.",p.pname) as addressID, trader.dr, trader.ar, trader.pr, CONCAT(trader.Hnr," หมู่ที่",trader.Vn,"  ต.",dis.dname," อ.",amp.aname," จ.",pro.pname) as addressReal, trader.phone, CONCAT(t.tname," : ",trader.detail) as typepor,CONCAT(typ.tname," : ",trader.detail2) as typepor2, q.TroF, trader.remark FROM trader LEFT JOIN district AS d ON trader.district = d.id LEFT JOIN amphures AS a ON trader.amphures = a.id LEFT JOIN province AS p ON trader.province = p.id LEFT JOIN district AS dis ON trader.dr = dis.id LEFT JOIN amphures AS amp ON trader.ar = amp.id LEFT JOIN province AS pro ON trader.pr = pro.id LEFT JOIN typeproduct AS t ON trader.typeproduct = t.id LEFT JOIN zone AS z ON trader.zone = z.id LEFT JOIN qrcode AS q ON trader.Qrcode = q.id LEFT join typeproduct as typ on trader.typeproduct2=typ.id WHERE trader.firstname IS NOT NULL AND z.id=7 ORDER BY trader.id;',(err,zone)=>{
            res.render('../views/Admin/Trader/zonechoose/zoneF',{
                data:zone,session:req.session
            });
        });
    });
};

controller.chooseG=(req,res) => {
    req.getConnection((err,conn) =>{
        conn.query('SELECT trader.id, z.zname, CONCAT(trader.firstname," ",trader.lastname) as FnLn, trader.idcard, CONCAT(trader.housenumber," หมู่ที่",trader.village," ต.",d.dname," อ.",a.aname," จ.",p.pname) as addressID, trader.dr, trader.ar, trader.pr, CONCAT(trader.Hnr," หมู่ที่",trader.Vn,"  ต.",dis.dname," อ.",amp.aname," จ.",pro.pname) as addressReal, trader.phone, CONCAT(t.tname," : ",trader.detail) as typepor,CONCAT(typ.tname," : ",trader.detail2) as typepor2, q.TroF, trader.remark FROM trader LEFT JOIN district AS d ON trader.district = d.id LEFT JOIN amphures AS a ON trader.amphures = a.id LEFT JOIN province AS p ON trader.province = p.id LEFT JOIN district AS dis ON trader.dr = dis.id LEFT JOIN amphures AS amp ON trader.ar = amp.id LEFT JOIN province AS pro ON trader.pr = pro.id LEFT JOIN typeproduct AS t ON trader.typeproduct = t.id LEFT JOIN zone AS z ON trader.zone = z.id LEFT JOIN qrcode AS q ON trader.Qrcode = q.id LEFT join typeproduct as typ on trader.typeproduct2=typ.id WHERE trader.firstname IS NOT NULL AND z.id=8 ORDER BY trader.id;',(err,zone)=>{
            res.render('../views/Admin/Trader/zonechoose/zoneG',{
                data:zone,session:req.session
            });
        });
    });
};

module.exports = controller;