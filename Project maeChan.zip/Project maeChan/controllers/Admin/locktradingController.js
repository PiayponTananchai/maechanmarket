const controller = {};
const { validationResult } = require('express-validator');

// Render the market selection view
controller.add = (req, res) => {
    req.getConnection((err, conn) => {
        if (err) {
            return res.status(500).json(err);
        }
        conn.query('SELECT market.id, market.name, t.thname, market.position, market.remark FROM market JOIN thesaban AS t ON market.thesaban = t.id', (err, chooseMarket) => {
            if (err) {
                return res.status(500).json(err);
            }
            conn.query('SELECT id, name FROM market', (err, market) => {
                if (err) {
                    return res.status(500).json(err);
                }
                res.render('../views/Admin/Locktrading/marketchooseView', {
                    data: chooseMarket,
                    market,
                    session: req.session
                });
            });
        });
    });
};

// Handle market selection submission
controller.addpost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/marketchoose/add');
    } else {
        const data = req.body;
        const market_id = data.market_id; // Ensure the form field is named "market_id"

        // Store market_id in the session
        req.session.market_id = market_id;

        req.session.success = true;
        req.session.topic = "เลือกตลาดสำเร็จ!";
        res.redirect('/marketdatechoose/add');
    }
};

// Render the market date selection view
controller.marketdateChoose = (req, res) => {
    req.getConnection((err, conn) => {
        if (err) {
            return res.status(500).json(err);
        }
        conn.query('SELECT md.id, md.seledate, mk.name, md.remark FROM marketdate AS md JOIN market AS mk ON md.market = mk.id;', (err, chooseMarketdate) => {
            if (err) {
                return res.status(500).json(err);
            }
            conn.query('SELECT id, seledate FROM marketdate', (err, marketdate) => {
                if (err) {
                    return res.status(500).json(err);
                }
                res.render('../views/Admin/Locktrading/marketDatechooseView', {
                    data: chooseMarketdate,
                    marketdate,
                    session: req.session
                });
            });
        });
    });
};

// Handle market date selection submission
controller.marketdatechooseAddpost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/marketdatechoose/list');
    } else {
        const data = req.body;
        const marketdate_id = data.marketdate_id; // Ensure the form field is named "marketdate_id"

        // Retrieve market_id from the session
        const market_id = req.session.market_id;

        req.getConnection((err, conn) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            const sql = 'INSERT INTO lock_trading (market_id, marketdate_id) VALUES (?, ?)';
            const values = [market_id, marketdate_id];
            conn.query(sql, values, (err) => {
                if (err) {
                    res.status(500).json(err);
                    return;
                }
                req.session.success = true;
                req.session.topic = "เพิ่มข้อมูลสำเร็จ!";
                res.redirect('/zonechoose/list');
            });
        });
    }
};

// Render the zone selection view
controller.choose = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('SELECT zone.id, zone.zname, zone.remark, market.name as market FROM zone JOIN market ON zone.market = market.id', (err, zone) => {
            res.render('../views/Admin/Locktrading/zonechooseView', {
                data: zone,
                session: req.session
            });
        });
    });
};

// Render the lock trading view for Zone A
controller.showA = (req, res) => {
    req.getConnection((err, conn) => {
        const query = `
            SELECT anm.id, u.uname as unitlock, 
                   CONCAT(td.firstname, " ", td.lastname) AS name
            FROM maechan_market.annualmember AS anm 
            JOIN unit AS u ON anm.unit = u.id 
            LEFT JOIN trader AS td ON anm.trader = td.id 
            JOIN zone AS z ON anm.zone = z.id 
            WHERE z.id = 1 
            ORDER BY anm.id DESC;
        `;

        conn.query(query, (err, locktrading) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            conn.query('SELECT id, annualmember_id, pay, clear FROM lock_trading', (err, lock_trading) => {
                if (err) {
                    res.status(500).json(err);
                    return;
                }

                res.render('../views/Admin/Locktrading/Zone/locktradingViewA', {
                    data: locktrading,
                    lock_trading,
                    session: req.session
                });
            });
        });
    });
};

// Handle adding lock trading data for Zone A
controller.addApost = (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.session.errors = errors;
        req.session.success = false;
        return res.redirect('/locktrading/a');
    } else {
        req.session.success = true;
        req.session.topic = "เพิ่มข้อมูลสำเร็จ!";

        const data = req.body;
        const entries = Object.keys(data).filter(key => key.startsWith('pay_')).map(key => {
            const annualmember_id = key.split('_')[1];
            return [annualmember_id, 1, 0]; // Assuming default values for pay and clear
        });

        req.getConnection((err, conn) => {
            if (err) {
                res.status(500).json(err);
                return;
            }
            
            const sql = 'INSERT INTO lock_trading (annualmember_id, pay, clear) VALUES ?';
            conn.query(sql, [entries], (err) => {
                if (err) {
                    res.status(500).json(err);
                    return;
                }
                res.redirect('/locktrading/a');
            });
        });
    }
};

// Handle clearing a lock trading entry
controller.clear = (req, res) => {
    const id = req.params.id;

    req.getConnection((err, conn) => {
        if (err) {
            return res.status(500).json(err);
        }

        const sql = 'UPDATE lock_trading SET clear = 1 WHERE id = ?';
        conn.query(sql, [id], (err) => {
            if (err) {
                return res.status(500).json(err);
            }
            res.redirect('/locktrading/a');
        });
    });
};

// Render the payment confirmation view
controller.confirmpay = (req, res) => {
    const data = req.body.data;
    res.render('../views/Admin/Locktrading/Zone/confirmPay', {
        data: data,
        session: req.session
    });
};

// Placeholder for rendering district view
controller.show = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('', (err, district) => {
            res.render('../views/Admin/District/districtView', {
                data: district,
                session: req.session
            });
        });
    });
};

module.exports = controller;